
#define ADDIN_API __declspec(dllexport)

/* Binary data stream structure */
#pragma pack(push, 8)

/*  Result value type codes  */

    /* These are used in the resbuf.  These ARE NOT the same
       as the group codes used in the entity access routines, and sould
       not be confused with those.  The same result buffer IS used for
       entity records, however, in which case the restype field may take
       on many more values than those listed here. */

#define RTNONE    5000                /* No result */
#define RTREAL    5001                /* Real number */
#define RTPOINT   5002                /* 2D point X and Y only */
#define RTSHORT   5003                /* Short integer */
#define RTANG     5004                /* Angle */
#define RTSTR     5005                /* String */
#define RTENAME   5006                /* Entity name */
#define RTPICKS   5007                /* Pick set */
#define RTORINT   5008                /* Orientation */
#define RT3DPOINT 5009                /* 3D point - X, Y, and Z */
#define RTLONG    5010                /* Long integer */
#define RTVOID    5014                /* Blank symbol */
#define RTLB      5016                /* list begin */
#define RTLE      5017                /* list end */
#define RTDOTE    5018                /* dotted pair */
#define RTNIL     5019                /* nil */
#define RTDXF0    5020                /* DXF code 0 for ads_buildlist only */
#define RTT       5021                /* T atom */
#define RTRESBUF  5023                /* resbuf */
#define RTMODELESS 5027               /* interrupted by modeless dialog */

typedef wchar_t ACHAR;

/* A real to AutoCAD is a double precision float, and must be
   used for all floating point numbers in AutoCAD. */
typedef double ads_real;

struct ads_binary {                   /* Binary data chunk structure */
    short clen;                       /* length of chunk in bytes */
    char *buf;                        /* binary data */
};
/*  Union for storing different ADS data types. */

union ads_u_val {
   ads_real rreal;
   ads_real rpoint[3];
   short rint;
   // Unicode: Leaving as char since R13dxf to R12dxf conversion is Ansi to Ansi
   ACHAR *rstring;
   long rlname[2];
   long rlong;
   struct ads_binary rbinary;
/* TEMPORARY probably, for internal use only at the moment */
   unsigned char ihandle[8];
};

/* The following is the structure definition of the general result buffer.
   This is used for both passing back results from functions, as well
   as exotic applications like entity lists, and command function lists.
   It is as close as we come to the AutoLISP node structure.  */

struct resbuf {
        struct resbuf *rbnext;        /* Allows them to be "linked" */
        short restype;
        union ads_u_val resval;
};

#pragma pack(pop)

extern "C" ADDIN_API HRESULT WINAPI AddIn_Resbuf(DWORD dwAddress, DEBUGHELPER *pHelper, int nBase, BOOL bUniStrings, char *pResult, size_t max, DWORD reserved );
