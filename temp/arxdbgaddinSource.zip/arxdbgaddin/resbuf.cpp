#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>
#include "atlbase.h"
#include "atlconv.h"

#include "custview.h"
#include "resbuf.h"

// S_OK    - succeeded, string terminated
// S_FALSE - succeeded, string needs to be truncated
// E_FAIL  - error processing string
HRESULT getDisplayString(DEBUGHELPER* pHelper, char* szDisplay, int nLen, DWORDLONG dwAddress)
{
	USES_CONVERSION;
	memset(szDisplay, '\0', nLen);

	if (dwAddress == 0)	// NULL
	{
		return S_OK;	// its actually ok to display ""
	}

	wchar_t* pszResbufString = new wchar_t[nLen];
	if (pszResbufString == NULL)
	{
		return E_OUTOFMEMORY;
	}
	wmemset(pszResbufString, L'\0', nLen);

	// The string length is unknown, therefore, to avoid possibly reading memory beyond the string, read
	// in one wchar_t character at a time.
	int nReadLen = 0;
	// Truncating strings to 80 characters, if the string is longer then displaying "..." at end.

	for (int i = 0; i < nLen; ++i, ++nReadLen)
	{
		wchar_t curChar = L'\0';
		DWORD	nGot = 0;
		HRESULT hr = pHelper->ReadDebuggeeMemoryEx(pHelper, dwAddress, sizeof(wchar_t), &curChar, &nGot);
		if (FAILED(hr) || nGot != sizeof(wchar_t))
		{
			delete[] pszResbufString;
			return E_FAIL;
		}
		pszResbufString[nReadLen] = curChar;
		if (curChar == L'\0')
		{
			break;
		}
		dwAddress = dwAddress + sizeof(wchar_t);
	}

	HRESULT hr = S_OK;
	if (pszResbufString[nReadLen] != L'\0')
	{
		// make sure we are null terminated and inform caller the length passed in
		// was not sufficient to hold the entire string
		hr = S_FALSE;
		pszResbufString[nReadLen] = L'\0';
	}
	strcpy_s(szDisplay, nLen, W2A(pszResbufString));

	delete[] pszResbufString;
	return hr;
}


ADDIN_API HRESULT WINAPI AddIn_Resbuf(DWORD dwAddress, DEBUGHELPER* pHelper, int nBase, BOOL bUniStrings, char* pResult, size_t max, DWORD reserved)
{
	resbuf rb;
	DWORD  nGot;

	// maximum string size that can be returned
	char* pszBuffer = new char[max];
	if (pszBuffer == NULL)
	{
		return E_OUTOFMEMORY;
	}
	memset(pszBuffer, '\0', max);

	// TODO: use nBase variable to display in decimal or hexadecimal

	// read resbuf from debuggee memory space
	HRESULT hr = pHelper->ReadDebuggeeMemoryEx(pHelper, pHelper->GetRealAddress(pHelper), sizeof(resbuf), &rb, &nGot);
	if (SUCCEEDED(hr) && nGot == sizeof(resbuf))
	{
		switch (rb.restype)
		{
		case RTNONE:                /* No result */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTNONE> rb.resval=<EMPTY>", 
				rb.restype);
			break;
		case RTREAL:                /* Real number */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTREAL> rb.resval.rreal=<%f>", 
				rb.restype, rb.resval.rreal);
			break;
		case RTPOINT:               /* 2D point X and Y only */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTPOINT> rb.resval.rpoint=<(%f, %f)>", 
				rb.restype, rb.resval.rpoint[0], rb.resval.rpoint[1]);
			break;
		case RTSHORT:               /* Short integer */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTSHORT> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTANG:                 /* Angle */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTANG> rb.resval.rreal=<%f>", 
				rb.restype, rb.resval.rreal);
			break;
		case RTDXF0:                /* DXF code 0 for ads_buildlist only */
		case RTSTR:                 /* String */
			{
				sprintf_s(pszBuffer, max, "restype=<%d,%s> rb.resval.string=<", rb.restype, 
						  rb.restype == RTSTR ? "RTSTR" : "RTDXF0");
				// -1 to provide room for ">"
				int nDisplayLen = max-strlen(pszBuffer)-1;
				if (nDisplayLen < 1)
				{
					delete[] pszBuffer;
					return E_UNEXPECTED;
				}
				char* pszDisplay = new char[nDisplayLen];
				if (pszDisplay == NULL)
				{
					delete[] pszBuffer;
					return E_OUTOFMEMORY;
				}
				hr = getDisplayString(pHelper, pszDisplay, nDisplayLen, 
									  reinterpret_cast<DWORDLONG>(rb.resval.rstring));
				if (SUCCEEDED(hr))
				{
					strcat_s(pszBuffer, max, pszDisplay);
					strcat_s(pszBuffer, max, ">");
				}
				delete[] pszDisplay;
			}
			break;
		case RTENAME:               /* Entity name */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTENAM, E> rb.resval.rlname=<%d, %d>", 
				rb.restype, rb.resval.rlname[0], rb.resval.rlname[1]);
			break;
		case RTPICKS:               /* Pick set */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTPICKS> rb.resval.rlname=<%d, %d>", 
				rb.restype, rb.resval.rlname[0], rb.resval.rlname[1]);
			break;
		case RTORINT:               /* Orientation */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTORINT> rb.resval.rreal=<%f>", 
				rb.restype, rb.resval.rreal);
			break;
		case RT3DPOINT:             /* 3D point - X, Y, and Z */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RT3DPOINT> rb.resval.rpoint=<(%f, %f, %f)>", 
				rb.restype, rb.resval.rpoint[0], rb.resval.rpoint[1], rb.resval.rpoint[2]);
			break;
		case RTLONG:                /* Long integer */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTLONG> rb.resval.rlong=<%d>", 
				rb.restype, rb.resval.rlong);
			break;
		case RTVOID:                /* Blank symbol */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTVOID> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTNIL:                 /* nil */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTNIL> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTT:                   /* T atom */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTT> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTLB:                  /* list begin */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTLB> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTLE:                  /* list end */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTLE> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTDOTE:                /* dotted pair */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTDOTE> rb.resval.rint=<%d>", 
				rb.restype, rb.resval.rint);
			break;
		case RTRESBUF:              /* resbuf */
			sprintf_s(pszBuffer, max, 
				"restype=<%d,RTRESBUF> rb.rbnext=<%d>", 
				rb.restype, reinterpret_cast<int>(rb.rbnext));
			break;
		case RTMODELESS:            /* interrupted by modeless dialog */
			// What is this? Seems like someone made an error as this appears to
			// be a return value like RTNORM and such.
		default:
			sprintf_s(pszBuffer, max, "restype=<%d>", rb.restype);
			break;
		}

		// copy to result buffer
		strcpy_s(pResult, max, pszBuffer);

		delete[] pszBuffer;
		hr = S_OK;
	}

	delete[] pszBuffer;
	return hr;
}
