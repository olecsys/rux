
// testmyServ.cpp : 
// TestClient for COM server: by Shoaib Ali
// you can submit your comments at alleey@usa.net.
//
// Test Application for the COM server all we need is the file containing the CLSID with by the way is
// not that neccessary however we still need the interface definition file as it gives us the prototype
// of all the methods and its uuid...
//


#include "stdafx.h"
#include <ComDef.h>
#include "..\myServ\myInterface.h"

void main()
{
	CoInitialize(0);
	HRESULT hr;
	ImyInterface *pmine=(0);
	hr = CoCreateInstance(CLSID_Mine,				// CLSID of COM server
						  NULL,						//
						  CLSCTX_INPROC_SERVER,		// it is a DLL 
						  __uuidof(ImyInterface),	// the interface IID
						  (void**)&pmine			// 
						  );
	if(FAILED(hr))
	{
		printf("failed to initialize COM server");
		return ;
	}

	long value = 10;
	printf("Enter a number : ") , scanf("%ld",&value);

	hr = pmine->Cube(&value);  // Call interface method 
	if(FAILED(hr))
		printf("failed square of ImyInterface.\n");
	else
		printf("Cube of the number is %ld. \n",value);

	pmine->Release();	// dont forget to do this ....								
}

