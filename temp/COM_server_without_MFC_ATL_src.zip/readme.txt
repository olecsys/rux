//////////////////////////////////////////////////////////////////////////////////////////
//
// COM server without MFC / ATL by Shoaib Ali..
// There  is no copyright for this code you can change it as you like
// you can contact me at alleey@usa.net
//
//
// project myServ: (Win32 regular Dll)
// COM server files. 
//
// project testmyServ: (Win32 console application)
// test driver for the component.

