// myInterface1.cpp: implementation of the CmyInterface class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "myInterface1.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CmyInterface::CmyInterface()
{

}

CmyInterface::~CmyInterface()
{

}

STDMETHODIMP CmyInterface::QueryInterface(REFIID riid,LPVOID *ppv)
{
	*ppv = NULL;
	if(IsEqualIID(riid,IID_IUnknown) || IsEqualIID(riid,__uuidof(ImyInterface)))
	{
		*ppv = (ImyInterface *) this;
		_AddRef();
		return S_OK;
	}
	return E_NOINTERFACE;
}

STDMETHODIMP CmyInterface::Square(long *pVal)
{
	long value = *pVal;
	*pVal = value * value;
	return S_OK;
}

STDMETHODIMP CmyInterface::Cube(long *pVal)
{
	long value = *pVal;
	*pVal = value * value * value;
	return S_OK;
}
