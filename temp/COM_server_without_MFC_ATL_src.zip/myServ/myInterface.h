
// sample interface 
// myInterface.h 
// a very simple COM server without MFC or ATL by :  Shoaib Ali
// you can send your comments at alleey@usa.net
//
// this file wil be required by the client as it contains the GUID and the interface definition
//

#include <ComDef.h>

// GUID of our COM server
_declspec(selectany) GUID CLSID_Mine = { 0xdc186800,
						  0x657f,
						  0x11d4, 
						  {	0xb0, 0xb5,  0x0,  0x50,  0xba,  0xbf,  0xc9,  0x4 	}
						};

// interface definition
// for sample COM server just replace the uuid of interface and its name
// and add new method prototypes here ..
// 
interface __declspec(uuid("F614FB00-6702-11d4-B0B7-0050BABFC904")) ImyInterface : public IUnknown
{
	STDMETHOD(Square)(long *pVal)PURE;
	STDMETHOD(Cube)(long *pVal)PURE;
};
