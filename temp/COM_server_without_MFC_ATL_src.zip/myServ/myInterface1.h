

// myInterface1.h
// a very simple COM server without MFC or ATL by :  Shoaib Ali
// you can send your comments at alleey@usa.net
//
#if !defined(AFX_MYINTERFACE1_H__1EAFF59A_66FF_11D4_B0B7_0050BABFC904__INCLUDED_)
#define AFX_MYINTERFACE1_H__1EAFF59A_66FF_11D4_B0B7_0050BABFC904__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ComBase.h"
#include "myInterface.h"

// sample use of the framework 
// this class implements a single interface ImyInterface ...
// 
class CmyInterface : public CComBase<> , public InterfaceImpl<ImyInterface> 
{
public:
	CmyInterface();
	virtual ~CmyInterface();

	// we however need to write code for queryinterface 
	STDMETHOD(QueryInterface)(REFIID riid,LPVOID *ppv);

	// ImyInterface methods
	STDMETHOD(Square)(long *pVal);
	STDMETHOD(Cube)(long *pVal);

};

#endif // !defined(AFX_MYINTERFACE1_H__1EAFF59A_66FF_11D4_B0B7_0050BABFC904__INCLUDED_)
