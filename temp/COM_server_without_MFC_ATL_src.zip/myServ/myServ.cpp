
// myServ.cpp 
// a very simple COM server without MFC or ATL by :  Shoaib Ali
// you can send your comments at alleey@usa.net
//
// there is no copyright of this code you cant change it and are free to use it anyway you like
// (i dont think you would anyway but..) if however you give me some credit for that i shall be highly
// obliged thanks in advance!! 
// 
// a simple COM dll that exposes just one interface ImyInterface with two methods Square and Cube
// this is basicaly a server written totaly in C++ without any MFC or ATL nor using any convoluted 
// macros ... ahhh.... it is very simple and not much customizable maybe, but this was just to get a
// COM object working .. so while you surf thru the code do the remember the word SIMPLE .. 
//
// Warning: this is not in any case a fully tested application and i donot guarantee it to be bug-free
// but there is none in my notice so far so if u happen to find one i would appreciate that + this may 
// have some weird kind of performance in cases, especialy i havent tested it for Singletons,finaly maybe 
// it has memory leaks .. yikes!!!!! ...... 
//

#include "stdafx.h"
#include "myServ.h"

long g_cRefThisDll;
HANDLE g_module;

#include "ClassFactory.h"
#include "MyInterface1.h"
#include "Registrar.h"

long * CObjRoot::p_ObjCount = NULL; // this is just because i didnt want to use any globals inside the
									// class framework.

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH: 
			g_module = hModule; 
			CObjRoot::p_ObjCount = &g_cRefThisDll; 
			break;

		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}



STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID *ppvOut)
{
	*ppvOut = NULL;
    if (IsEqualIID(rclsid, CLSID_Mine))
    {
       // declare a classfactory for CmyInterface class 
       CClassFactory<CmyInterface> *pcf = new  CClassFactory<CmyInterface>;
       return pcf->QueryInterface(riid,ppvOut);
    }
    return CLASS_E_CLASSNOTAVAILABLE;
}

STDAPI  DllCanUnloadNow(void)
{
    return (g_cRefThisDll == 0 ? S_OK : S_FALSE);
}

STDAPI DllRegisterServer(void)
{
	CDllRegistrar registrar;  // this class should create standard entries in registry 
	char path [ MAX_PATH ];
	GetModuleFileName((HMODULE)g_module,path,MAX_PATH);
	return registrar.RegisterObject(CLSID_Mine,"MineLib","MathObj",path) ? S_OK:S_FALSE;
}

STDAPI DllUnregisterServer(void)
{
	CDllRegistrar registrar;
	return registrar.UnRegisterObject(CLSID_Mine,"MineLib","MathObj") ? S_OK:S_FALSE;
}

