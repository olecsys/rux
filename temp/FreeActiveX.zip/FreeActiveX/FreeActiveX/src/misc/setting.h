
#ifndef _SETTINGS_ACTIVEX_
#define _SETTINGS_ACTIVEX_

    // name of page
    #define PAGE_OF_PROGRAM "http://unick-soft.xost.ru"



#endif